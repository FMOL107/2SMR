var width = window.innerWidth;
var height = window.innerHeight;

var scale = Math.max(width/800.0, height/600.0);

var config = {
    type: Phaser.AUTO,
    width: width, // 800,
    height: height, // 600,
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 850 },
            debug: false
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

var platforms;
var cursors, joyStick;
var player;
var enemySpeed = 100;
var coins;
var bombs;    
var score = 0;
var scoreText;
var hearts;
var life = 3;
var scoreLife;
var gameOver = false;    
var lastanim;
var config_audio = {mute: false,
    volume: 0.1,
    detune: 0,
    seek: 0,
    loop: true,
    delay: 0};

var game = new Phaser.Game(config);

function preload ()
{
    // Load joyStick
    this.load.plugin('rexvirtualjoystickplugin', 'rexvirtualjoystickplugin.min.js', true);        
    
    this.load.image('background', 'assets/background.png');
    this.load.image('ground', 'assets/ground.png');
    this.load.image('platform', 'assets/platform.png');
    this.load.image('block', 'assets/block.png');

    this.load.tilemapTiledJSON('map', 'assets/centerplatform.json');
    this.load.image('fondo', 'assets/texture.png');

    this.load.spritesheet('dudeL', 'assets/knight_runL.png', { frameWidth: 16, frameHeight: 22 });
    this.load.spritesheet('dudeR', 'assets/knight_runR.png', { frameWidth: 16, frameHeight: 22 });
    this.load.spritesheet('dude', 'assets/dudeturn.png', { frameWidth: 16, frameHeight: 20 });
    this.load.spritesheet('coin', 'assets/coin.png', { frameWidth: 16, frameHeight: 28 });
    this.load.audio('coinaudio', 'assets/coin.mp3',);
    this.load.spritesheet('bomb', 'assets/bomb.png', { frameWidth: 16, frameHeight: 16 });
    this.load.audio('generalaudio', 'assets/spy.mp3');
    this.load.audio('bombaudio', 'assets/fire.mp3');
    this.load.bitmapFont('myfont1', 'assets/font1.png', 'assets/font1.fnt');
    this.load.bitmapFont('myfont2', 'assets/font2.png', 'assets/font2.fnt');
    this.load.bitmapFont('myfont3', 'assets/font3.png', 'assets/font3.fnt');
    this.load.spritesheet('heart', 'assets/heart.png', { frameWidth: 17, frameHeight: 17 });
    this.load.audio('heartaudio', 'assets/heart.mp3');
    this.load.audio('losehealtaudio', 'assets/losehealt.mp3');
    this.load.audio('gameoveraudio', 'assets/gameover.mp3');
    this.load.spritesheet('enemyR', 'assets/enemyR.png', { frameWidth: 34, frameHeight: 38 });
    this.load.spritesheet('enemyL', 'assets/enemyL.png', { frameWidth: 34, frameHeight: 38 });
    this.load.audio('enemyaudio', 'assets/enemy.mp3');
}

function create ()
{
    generalaudio = this.sound.add('generalaudio', 'config_audio');
    generalaudio.play(config_audio);

    //this.add.image(400, 300, 'sky');
    this.add.image(width/2, height/2, 'background').setScale(scale);
    
    var map = this.make.tilemap({ key: 'map' });
    var tileset = map.addTilesetImage('inca_front', 'fondo');
    var fondo = map.createStaticLayer("Capa de patrones 1", tileset, width/4, height/2.5).setScale(scale);
    
    fondo.setCollisionByExclusion(-1, true);


    platforms = this.physics.add.staticGroup();
    
    //platforms.create(400, 568, 'ground').setScale(2).refreshBody();
    platforms.create(width/2, height-scale*22, 'ground').setScale(scale).refreshBody();

    //platforms.create(600, 400, 'ground');
    platforms.create(width/2-275*scale, height/4.3, 'platform').setScale(scale).refreshBody();
    platforms.create(width/2+275*scale, height/4.3, 'platform').setScale(scale).refreshBody();

    //platforms.create(width/2, height/2.25, 'platform').setScale(scale).refreshBody();

    platforms.create(width/2-485*scale, height/1.8, 'platform').setScale(scale).refreshBody();
    platforms.create(width/2+485*scale, height/1.8, 'platform').setScale(scale).refreshBody();
    
    //platforms.create(50, 250, 'ground');
    platforms.create(width/2-300*scale, height/1.4, 'platform').setScale(scale).refreshBody();
    platforms.create(width/2+300*scale, height/1.4, 'platform').setScale(scale).refreshBody();
    
    //player = this.physics.add.sprite(100, 450, 'dude');
    player = this.physics.add.sprite(width/2, height/2, 'dude').setScale(scale*1.5);

    //add enemy
    enemy = this.physics.add.sprite(width/2, height/3, 'enemyR').setScale(scale);
    enemy.body.velocity.x = enemySpeed;
    //enemy.anims.play('enemyleft', true);
    
    this.anims.create({
        key: 'enemyL',
        frames: this.anims.generateFrameNumbers('enemyL', { start: 0, end: 7 }),
        frameRate: 10,
        repeat: -1
    });

    this.anims.create({
        key: 'enemyR',
        frames: this.anims.generateFrameNumbers('enemyR', { start: 0, end: 7 }),
        frameRate: 10,
        repeat: -1
    });

    
    player.setBounce(0.09);
    player.setCollideWorldBounds(true);
    
    this.anims.create({
        key: 'left',
        frames: this.anims.generateFrameNumbers('dudeL', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });

    this.anims.create({
        key: 'turn',
        frames: [ { key: 'dude0', frame: 0 } ],
        frameRate: 20
    });

    this.anims.create({
        key: 'turn0',
        frames: [ { key: 'dude', frame: 0 } ],
        frameRate: 20
    });

    this.anims.create({
        key: 'turn1',
        frames: [ { key: 'dude', frame: 1 } ],
        frameRate: 20
    });
    
    this.anims.create({
        key: 'right',
        frames: this.anims.generateFrameNumbers('dudeR', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });
    
    //  Input Events
    cursors = this.input.keyboard.createCursorKeys();

    //  Some coins to collect, 12 in total, evenly spaced along the x axis        
    coins = this.physics.add.group({
        key: 'coin',
        repeat: 11,
        // setXY: { x: 12, y: 0, stepX: 70 }
        setXY: { x: width/13, y: 0, stepX: width/13 }
    });

    this.anims.create({
        key: 'coin',
        frames: this.anims.generateFrameNumbers('coin', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });

    //  Scale the coins and give each star a slightly different bounce
    coins.children.iterate(function (child) {
        child.setScale(scale/1.5);
        child.setBounceY(Phaser.Math.FloatBetween(0.4, 0.8));
        child.anims.play('coin'); 
    });
    

    hearts = this.physics.add.group({
        key: 'heart',
        repeat: 0,
        setXY: { x: Phaser.Math.FloatBetween(0, width), y: 0, stepX: width/20}
    });

    this.anims.create({
        key: 'heart',
        frames: this.anims.generateFrameNumbers('heart', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });

    hearts.children.iterate(function (child) {
        child.setScale(scale);
        child.setBounceY(Phaser.Math.FloatBetween(0.2, 0.0));
        child.anims.play('heart');
    });

    bombs = this.physics.add.group();    
    
    //  The score
    var fontSize = 18*scale;
    scoreText = this.add.bitmapText(16, 5, 'myfont1', 'Score ' + score, fontSize);
    scoreLife = this.add.bitmapText(16, 45, 'myfont2', 'Life ' + life, fontSize);
    
    //  Collide the player, the coins and the bombs with the platforms        
    this.physics.add.collider(player, platforms);
    this.physics.add.collider(coins, platforms);
    this.physics.add.collider(bombs, platforms);    
    this.physics.add.collider(hearts, platforms);    
    this.physics.add.collider(enemy, platforms);
    this.physics.add.collider(enemy, fondo);
    this.physics.add.collider(coins, fondo);
    this.physics.add.collider(bombs, fondo);    
    this.physics.add.collider(hearts, fondo);
    this.physics.add.collider(player, fondo);

    //  Checks to see if the player overlaps with any of the coins, if he does call the collectStar function
    this.physics.add.overlap(player, coins, collectStar, null, this);

    this.physics.add.overlap(player, hearts, collectHearts, null, this);

    //  Checks to see if the player overlaps with the bombs, if he does call the hitBomb function        
    this.physics.add.collider(player, bombs, hitBomb, null, this);        
   
    joyStick = this.plugins.get('rexvirtualjoystickplugin').add(this, {
        x: width-60*scale,
        y: height-60*scale,
        radius: 15*scale,
        base: this.add.graphics().fillStyle(0x888888).fillCircle(0, 0, 30*scale*1.3),
        thumb: this.add.graphics().fillStyle(0xcccccc).fillCircle(0, 0, 15*scale*1.3)
    }).on('update', update, this);    
}

function update ()
{
    enemy.anims.play('enemyR', true);
    // enemy touching a wall on the right
    if(enemy.body.blocked.right){
        // horizontal flipping enemy sprite
        enemy.flipX = true;
    }
    // same concept applies to the left
    if(enemy.body.blocked.left){
        enemy.flipX = false;
        enemy.anims.play('enemyL', true);
    }

    // adjusting enemy speed according to the direction it's moving
    enemy.body.velocity.x = enemySpeed * (enemy.flipX ? -1 : 1);

    this.physics.world.collide(player, enemy, function(player, enemy){
        if(enemy.body.touching.up && player.body.touching.down){
            player.setVelocityY(-300*scale);
        }
        else{
            life--;
            var enemyaudio = this.sound.add('enemyaudio');
            
            if(life > 0) {
                enemyaudio.play();
            }

            scoreLife.setText('Life ' + life);
            if (life === 0) {
                gameoveraudio = this.sound.add('gameoveraudio');
                generalaudio.stop();
                enemyaudio.stop();
                gameoveraudio.play();
                this.physics.pause();
                player.setTint(0xff0000);
                player.anims.play("lastanim");
                gameOver = true;
                // Fernando: After game over, you can restart the game
                var fontSize = 20*scale;
                var text = this.add.bitmapText(width/2, height/2, 'myfont3', 'GAME OVER. Click here to continue', fontSize);
                text.setInteractive();
                text.setOrigin(0.5);
                text.on('pointerdown', function () {
                    location.reload();
                });
            }
        }
    }, null, this);


   
    if (cursors.left.isDown || joyStick.left)
    {
        if (player.x < 50) player.x = width;
        
        //player.setVelocityX(-160);
        player.setVelocityX(-160*scale);
    
        player.anims.play('left', true);

        lastanim = 0;
    }
    else if (cursors.right.isDown || joyStick.right)
    {
        if (player.x > (width-50)) player.x = 0;
        
        //player.setVelocityX(160);
        player.setVelocityX(160*scale);
    
        player.anims.play('right', true);

        lastanim = 1;
    }
    else
    {
        player.setVelocityX(0);
    
        if(lastanim === 0){

            player.anims.play('turn0', true);

        } else {

            player.anims.play('turn1', true);

        }

        
    }
   
    if (((cursors.up.isDown || joyStick.up) && player.body.touching.down) || ((cursors.up.isDown || joyStick.up) && player.body.onFloor()))
    {
        //player.setVelocityY(-330);
        player.setVelocityY(-350*scale);
    }   
}

function anotherHeart() {
    hearts.children.iterate(function (child) {
        child.enableBody(true, Phaser.Math.Between(0, width), 0, true, true);
    });        
}

function collectHearts (player, heart)
{
    var heartaudio = this.sound.add('heartaudio');
    heartaudio.play();
    heart.disableBody(true, true);
    life ++;
    scoreLife.setText('Life ' + life);   
}

function collectStar (player, star)
{
    if ((hearts.countActive(true) === 0) && ((score % 100) === 0)) {
            setTimeout(this.anotherHeart, Phaser.Math.Between(0, 2000));
        } 
    
    var coinaudio = this.sound.add('coinaudio');
    coinaudio.play();
    star.disableBody(true, true);
    
    score += 10;
    scoreText.setText('Score:' + score);
    
    if (coins.countActive(true) === 0)
    {
        //  A new batch of coins to collect
        coins.children.iterate(function (child) {
            child.enableBody(true, child.x, 0, true, true);
        });

        //var x = (player.x < 400) ? Phaser.Math.Between(400, 800) : Phaser.Math.Between(0, 400);

        for (i = 0; i < 3; i++){
            var x = (player.x < width/2) ? Phaser.Math.Between(width/2, width) : Phaser.Math.Between(0, width/2);
            var bomb = bombs.create(x, 16, 'bomb').setScale(scale);
            bomb.setBounce(1);
            bomb.setCollideWorldBounds(true);
            bomb.setVelocity(Phaser.Math.Between(-200, 200), 20);
            bomb.allowGravity = false;
            bomb.anims.play('bombanim'); 
            var bombaudio = this.sound.add('bombaudio');
            bombaudio.play();
        }
        
    }   

    this.anims.create({
        key: 'bombanim',
        frames: this.anims.generateFrameNumbers('bomb', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });
} 


function hitBomb (player, bomb)
{
    var losehealtaudio = this.sound.add('losehealtaudio');
    losehealtaudio.play();
    bomb.disableBody(true, true);

    life--;

    scoreLife.setText('Life ' + life);
    if (life === 0) {
        gameoveraudio = this.sound.add('gameoveraudio');
        gameoveraudio.play();
        this.physics.pause();
        player.setTint(0xff0000);
        player.anims.play("lastanim");
        gameOver = true;
        // Fernando: After game over, you can restart the game
        var fontSize = 20*scale;
        var text = this.add.bitmapText(width/2, height/2, 'myfont3', 'GAME OVER. Click here to continue', fontSize);
        text.setInteractive();
        text.setOrigin(0.5);
        text.on('pointerdown', function () {
            location.reload();
        });
    }
}