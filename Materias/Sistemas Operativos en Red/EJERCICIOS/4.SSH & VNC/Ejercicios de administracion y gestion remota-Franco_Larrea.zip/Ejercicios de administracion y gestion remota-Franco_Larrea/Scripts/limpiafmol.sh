#!/bin/bash

apt-get autoclean ; apt-get autoremove

echo cleaning done on `date +%d/%m/%y` at `date +%X` >> /home/fmol107/loglimpieza.txt




